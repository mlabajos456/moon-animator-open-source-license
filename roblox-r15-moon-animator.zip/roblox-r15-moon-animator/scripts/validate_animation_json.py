#!/usr/bin/env python3
"""Validate an animation JSON file against this repository's R15 authoring contract."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any


R15_JOINTS = {
    "LowerTorso",
    "UpperTorso",
    "Head",
    "RightUpperArm",
    "RightLowerArm",
    "RightHand",
    "LeftUpperArm",
    "LeftLowerArm",
    "LeftHand",
    "RightUpperLeg",
    "RightLowerLeg",
    "RightFoot",
    "LeftUpperLeg",
    "LeftLowerLeg",
    "LeftFoot",
}
AXES = ("x", "y", "z")


def is_finite_number(value: Any) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def load_animation(source: str) -> tuple[dict[str, Any] | None, str | None]:
    try:
        raw = sys.stdin.read() if source == "-" else Path(source).read_text(encoding="utf-8-sig")
    except OSError as exc:
        return None, f"no se pudo leer el archivo: {exc}"

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        return None, f"JSON inválido en línea {exc.lineno}, columna {exc.colno}: {exc.msg}"

    if isinstance(data, dict) and isinstance(data.get("animation"), dict):
        data = data["animation"]
    if not isinstance(data, dict):
        return None, "la raíz debe ser un objeto JSON"
    if not isinstance(data.get("keyframes"), list):
        return None, "falta `keyframes` como arreglo"
    return data, None


def validate(animation: dict[str, Any], check_loop: bool = False) -> tuple[list[str], list[str], int, int]:
    errors: list[str] = []
    warnings: list[str] = []
    keyframes = animation["keyframes"]
    seen: set[tuple[str, int]] = set()
    joints: set[str] = set()
    frame_values: list[int] = []
    poses_by_joint: dict[str, dict[int, dict[str, Any]]] = {}

    total_frames = animation.get("total_frames")
    if total_frames is not None:
        if not is_finite_number(total_frames) or total_frames < 0 or not float(total_frames).is_integer():
            errors.append("`total_frames` debe ser un entero no negativo")
            total_frames = None
        else:
            total_frames = int(total_frames)

    for index, keyframe in enumerate(keyframes):
        label = f"keyframes[{index}]"
        if not isinstance(keyframe, dict):
            errors.append(f"{label} debe ser un objeto")
            continue

        joint = keyframe.get("joint")
        if not isinstance(joint, str) or not joint.strip():
            errors.append(f"{label}.joint debe ser un nombre de pieza no vacío")
        else:
            joint = joint.strip()
            joints.add(joint)
            if joint not in R15_JOINTS and joint.split(".")[-1] not in R15_JOINTS:
                warnings.append(f"{label}: joint `{joint}` no pertenece a los 15 nombres R15 estándar; el importador puede omitirlo")

        frame = keyframe.get("frame")
        if not is_finite_number(frame) or frame < 0 or not float(frame).is_integer():
            errors.append(f"{label}.frame debe ser un entero no negativo")
            valid_frame = None
        else:
            valid_frame = int(frame)
            frame_values.append(valid_frame)

        if joint and isinstance(joint, str) and valid_frame is not None:
            pair = (joint, valid_frame)
            if pair in seen:
                errors.append(f"par duplicado ({joint}, {valid_frame})")
            seen.add(pair)
            poses_by_joint.setdefault(joint, {}).setdefault(valid_frame, keyframe)

        for field in ("rotation", "position"):
            vector = keyframe.get(field)
            if not isinstance(vector, dict):
                errors.append(f"{label}.{field} debe ser un objeto con x, y, z")
                continue
            for axis in AXES:
                value = vector.get(axis)
                if not is_finite_number(value):
                    errors.append(f"{label}.{field}.{axis} debe ser un número finito")

    if not keyframes:
        errors.append("`keyframes` no puede estar vacío")
    if total_frames is not None and frame_values and max(frame_values) > total_frames:
        errors.append(f"el frame máximo ({max(frame_values)}) supera `total_frames` ({total_frames})")

    if check_loop:
        if total_frames is None or total_frames <= 0:
            errors.append("`--loop` requiere `total_frames` como entero mayor que cero")
        else:
            for joint, poses in poses_by_joint.items():
                start = poses.get(0)
                end = poses.get(total_frames)
                if start is None:
                    errors.append(f"`--loop`: {joint} no tiene pose en frame 0")
                    continue
                if end is None:
                    errors.append(f"`--loop`: {joint} no tiene pose en total_frames ({total_frames})")
                    continue
                start_rotation = start.get("rotation")
                end_rotation = end.get("rotation")
                start_position = start.get("position")
                end_position = end.get("position")
                vectors = (start_rotation, end_rotation, start_position, end_position)
                if not all(isinstance(vector, dict) and all(axis in vector for axis in AXES) for vector in vectors):
                    continue
                if start_rotation != end_rotation or start_position != end_position:
                    errors.append(f"`--loop`: pose inicial y final de {joint} no coinciden")

    return errors, warnings, len(joints), max(frame_values, default=0)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("json_file", help="archivo JSON, o '-' para leer desde stdin")
    parser.add_argument("--loop", action="store_true", help="exige poses iguales en frame 0 y total_frames para cada joint animado")
    args = parser.parse_args()

    animation, load_error = load_animation(args.json_file)
    if load_error:
        print(f"ERROR: {load_error}", file=sys.stderr)
        return 1

    assert animation is not None
    errors, warnings, joint_count, max_frame = validate(animation, check_loop=args.loop)
    for warning in warnings:
        print(f"AVISO: {warning}")
    for error in errors:
        print(f"ERROR: {error}", file=sys.stderr)

    if errors:
        print(f"JSON no válido: {len(errors)} error(es), {len(warnings)} aviso(s).")
        return 1

    name = animation.get("animation_name", "(sin nombre)")
    print(f"JSON válido: {name}; {len(animation['keyframes'])} keyframes; {joint_count} joints; frame máximo {max_frame}.")
    if args.loop:
        print("Costura de loop válida: inicio y final coinciden para todos los joints animados.")
    if warnings:
        print(f"Revisa los {len(warnings)} aviso(s) antes de importarlo en el rig objetivo.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
