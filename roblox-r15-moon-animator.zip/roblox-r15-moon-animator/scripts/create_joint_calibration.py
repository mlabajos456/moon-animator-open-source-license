#!/usr/bin/env python3
"""Create a small isolated +/- local-axis calibration animation for an R15 joint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from validate_animation_json import R15_JOINTS


PHASES = ((0, 0), (8, 0), (12, 1), (24, 1), (28, 0), (40, 0), (44, -1), (56, -1), (60, 0))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--joint", required=True, choices=sorted(R15_JOINTS), help="pieza corporal R15 que quieres calibrar")
    parser.add_argument("--axis", required=True, choices=("x", "y", "z"), help="eje local que quieres observar")
    parser.add_argument("--channel", choices=("rotation", "position"), default="rotation", help="calibrar grados de rotación o studs de posición")
    parser.add_argument("--amount", type=float, help="magnitud positiva; predeterminados: 5 grados o 0.05 studs")
    parser.add_argument("--target", default="Rig", help="nombre exacto del objetivo en el plugin")
    parser.add_argument("--output", type=Path, help="ruta de salida; por defecto se crea junto al directorio actual")
    args = parser.parse_args()

    amount = args.amount if args.amount is not None else (5.0 if args.channel == "rotation" else 0.05)
    if not math.isfinite(amount) or amount <= 0:
        parser.error("--amount debe ser un número finito mayor que cero")
    if not args.target.strip():
        parser.error("--target no puede estar vacío")

    anim_name = f"calibrar_{args.joint}_{args.channel}_{args.axis}_r15"
    keyframes = []
    for frame, sign in PHASES:
        rotation = {"x": 0, "y": 0, "z": 0}
        position = {"x": 0, "y": 0, "z": 0}
        if args.channel == "rotation":
            rotation[args.axis] = sign * amount
        else:
            position[args.axis] = sign * amount
        keyframes.append({
            "joint": args.joint,
            "frame": frame,
            "rotation": rotation,
            "position": position,
        })

    unit = "grados" if args.channel == "rotation" else "studs"
    positive_label = f"+{amount:g} {unit}"
    negative_label = f"−{amount:g} {unit}"
    animation = {
        "animation_name": anim_name,
        "description": f"Calibración aislada de {args.joint}.{args.axis}: +{amount:g} y -{amount:g} {unit}, con retornos a neutral",
        "total_frames": 60,
        "fps": 60,
        "intensity": 1,
        "target_name": args.target.strip(),
        "calibration": {
            "joint": args.joint,
            "channel": args.channel,
            "axis": args.axis,
            "amount": amount,
            "unit": unit,
            "phases": [
                {"start_frame": 0, "end_frame": 8, "label": "Neutral"},
                {"start_frame": 9, "end_frame": 11, "label": f"Hacia {positive_label}"},
                {"start_frame": 12, "end_frame": 24, "label": positive_label},
                {"start_frame": 25, "end_frame": 27, "label": "Volviendo a neutral"},
                {"start_frame": 28, "end_frame": 40, "label": "Neutral"},
                {"start_frame": 41, "end_frame": 43, "label": f"Hacia {negative_label}"},
                {"start_frame": 44, "end_frame": 56, "label": negative_label},
                {"start_frame": 57, "end_frame": 59, "label": "Volviendo a neutral"},
                {"start_frame": 60, "end_frame": 60, "label": "Neutral"},
            ],
        },
        "keyframes": keyframes,
    }

    output = args.output or Path(f"{anim_name}.json")
    output.write_text(json.dumps(animation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Creado: {output.resolve()}")
    print("Observa la articulación en los frames 12–24 (+) y 44–56 (-); el resto vuelve a neutral.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
