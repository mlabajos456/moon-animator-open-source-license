# Animación corporal R15 para Moon Animator 2

Produce animaciones legibles, equilibradas y técnicamente importables. Separa siempre la biomecánica artística de los hechos comprobados del rig y del importador.

## Nivel de certeza

Clasifica cada decisión en una de estas capas:

1. **Contrato técnico comprobado:** comportamiento documentado por Roblox o leído en el código de este repositorio.
2. **Hecho observado en el rig objetivo:** eje, signo o límite confirmado en el viewport sobre ese rig concreto.
3. **Heurística de animación:** principio útil como peso, anticipación, arcos o follow-through.
4. **Hipótesis:** valor numérico o signo aún no validado visualmente.

No presentes una heurística ni una calibración local como una ley universal. Moon Animator 2 v36000 está confirmado por su ficha oficial, pero no hay un changelog público detallado que permita atribuirle flujos nuevos concretos. Si una ruta de menú cambió, describe el objetivo de la operación y verifica la interfaz actual.

## Compatibilidad de versión y rig

- La versión comercial oficial vigente es v36000.
- El código abierto de este repositorio declara `_g.ver = 34000`. El importador AI Fight Animator es una extensión local de esa copia; no asumas que forma parte del Moon Animator 2 comercial.
- Usa la interfaz oficial v36000 para instrucciones de usuario actuales y el código local para describir únicamente el contrato de esta extensión JSON.
- Roblox puede crear R15 nuevos con `AnimationConstraint` en lugar de `Motor6D` cuando Avatar Joint Upgrade está habilitado. Esta copia local no contiene manejo explícito de `AnimationConstraint`.
- Antes de generar una animación completa, confirma que Moon Animator detecta el rig, crea los quince tracks esperados y permite keyframearlos. Si no lo hace, diagnostica primero el tipo de joint y la versión del plugin; no cambies attachments ni la pose T a ciegas.

## Determinar el entregable

Identifica antes de animar:

- acción e intención emocional;
- estilo: realista, Roblox rígido, cartoon, anime, mocap o cinematográfico;
- rig y proporciones: blocky R15, avatar del jugador o R15 personalizado;
- uso: gameplay, idle/locomoción, emote, combate o cutscene;
- duración, FPS, bucle y prioridad;
- desplazamiento in-place o movimiento real del personaje;
- contactos obligatorios con suelo, adversario u objeto;
- lado dominante y cámara principal;
- salida solicitada: guía de poses, tabla de frames, JSON o revisión.

Si faltan datos y no cambian materialmente el resultado, usa estos valores y decláralos:

- R15 blocky estándar;
- 60 FPS, que es el valor predeterminado de esta copia del plugin;
- animación in-place;
- no loop, salvo locomoción o idle;
- frame 0 como inicio del clip JSON;
- rotación XYZ en grados y posición en studs.

Pregunta solo cuando la respuesta cambie el movimiento de forma material, por ejemplo gameplay frente a cutscene, loop frente a acción única o rig blocky frente a avatar de proporciones extremas.

## Modelo mental correcto de R15

Roblox aplica cada `Pose.CFrame` al joint que conecta la parte nombrada con su padre. Las transformaciones son locales y jerárquicas; no son rotaciones independientes en ejes globales.

Jerarquía corporal práctica:

```text
HumanoidRootPart
└─ LowerTorso
   ├─ UpperTorso
   │  ├─ Head
   │  ├─ RightUpperArm → RightLowerArm → RightHand
   │  └─ LeftUpperArm  → LeftLowerArm  → LeftHand
   ├─ RightUpperLeg → RightLowerLeg → RightFoot
   └─ LeftUpperLeg  → LeftLowerLeg  → LeftFoot
```

Consecuencias:

- `LowerTorso` organiza masa, altura, inclinación y dirección global visual.
- `UpperTorso` aporta contragiro, compresión, expansión y orientación del pecho.
- `Head` dirige atención y estabiliza la lectura; no debe copiar mecánicamente todo el giro del torso.
- `UpperArm` y `UpperLeg` definen la trayectoria principal de cada extremidad.
- `LowerArm` y `LowerLeg` controlan flexión, alcance y silueta, sin reemplazar al segmento proximal como origen del gesto.
- `Hand` y `Foot` afinan contacto, orientación y línea final.
- una rotación del padre cambia la lectura mundial de todos sus hijos;
- el mismo valor puede verse distinto en otro avatar R15 por proporciones, pose base o retargeting.

### Aplicación real de Motor6D y rigs R15 actuales

En un rig que usa `Motor6D`, no confundas el `CFrame` de una `Pose` con `C0` o `C1`. Roblox conserva ambos anclajes y el Animator escribe el offset animado en `Motor6D.Transform`. El rig mantiene la relación:

```text
Part0.CFrame * C0 * Transform = Part1.CFrame * C1
Part1.CFrame = Part0.CFrame * C0 * Transform * C1:Inverse()
```

En un `Keyframe`, la pose se identifica por el nombre de la pieza conectada, no necesariamente por `Motor6D.Name`: por ejemplo, `Pose "LowerTorso"` anima el motor `Root`, que conecta `HumanoidRootPart` con `LowerTorso`. La jerarquía de `Pose` sigue la jerarquía de joints; cada pose transforma su pieza hija respecto del padre.

Para orientar visualmente el cuerpo durante una acción, anima el giro Y de `LowerTorso` (la pose del motor `Root`) y coordínalo con el resto de joints; devuelve ese valor al final si el personaje debe acabar mirando al frente. Esto rota `LowerTorso` y sus descendientes respecto a `HumanoidRootPart`, pero no cambia por sí solo la orientación del `HumanoidRootPart` ni desplaza al personaje por el mundo. Mantén la cámara fija al evaluar un giro del rig, para distinguir la rotación del personaje de la órbita de cámara.

**Patrón aprobado en el visor local — giro y marcha:** el ciclo `giro_y_marcha_r15.json` pivota el `LowerTorso` hacia un costado, mantiene la orientación durante tres pasos alternados y vuelve al frente. Los brazos acompañan en oposición a las piernas y los extremos del clip comparten la pose neutral para permitir repetición sin salto. El usuario confirmó que el resultado se ve bien en el visor; esto valida el patrón visual local, no la orientación física del `HumanoidRootPart` en Studio.

**Patrón aprobado en el visor local — salto y aterrizaje:** `salto_y_aterrizaje_r15.json` organiza compresión, elevación visual, piernas recogidas, impacto y recuperación. En el adaptador local, `LowerTorso.position.y` negativo eleva el cuerpo visible y un valor positivo lo comprime hacia abajo. El usuario confirmó que el resultado se ve bien en el visor; este offset no mueve el `HumanoidRootPart` ni sustituye la física de salto del juego.

Para este importador, el JSON se convierte en `baseCFrame * CFrame.new(position) * CFrame.Angles(rx, ry, rz)` y ese valor se almacena como `Pose.CFrame`. La animación aplica la pose vía `Transform`; no reescribas `C0` ni `C1`. `CFrame.Angles` usa orden XYZ, equivalente a `CFrame.fromEulerAnglesXYZ`, y sus ángulos están en radianes después de convertir los grados del JSON.

`Motor6D.Transform` es el offset de animación del motor y no se replica directamente. Cuando un `Animator` controla el rig, normalmente sobrescribe `Transform` cada frame después de `RunService.PreAnimation` y antes de `RunService.PreSimulation`; después, Roblox aplica las transformaciones en lote justo antes de la simulación física. El JSON debe alimentar la animación, no depender de escribir `Transform` manualmente mientras el Animator también controla el rig.

**Comprueba qué tipo de joints tiene el avatar antes de describirlo como Motor6D.** Con `AvatarJointUpgrade`, los personajes R15 de experiencias nuevas usan `AnimationConstraint` por defecto. Su propiedad `Transform` cumple el mismo papel animado, pero los anclajes vienen de `Attachment0` y `Attachment1`; `C0`, `C1`, `Part0` y `Part1` son alias de solo lectura, y no se deben editar los `RigAttachment.CFrame`. Las poses siguen correspondiendo a las piezas/joints de la jerarquía. Para diagnosticar en Studio, identifica el tipo real de joint y los nombres de piezas; no infieras la configuración a partir del nombre del joint solamente.

**No fijes un signo universal por nombre de eje.** El signo visible depende de la orientación del joint, `C0`, `C1`, la convención del JSON y el rig. La ecuación de Roblox define cómo se resuelve el `Motor6D`; no basta por sí sola para deducir qué signo debe recibir un JSON en un visor geométrico aproximado. Calibra en el rig de Studio con un offset pequeño por eje antes de reutilizar la regla.

**Límite del visor local:** la geometría local es un rig aproximado con pivotes estilo `Motor6D`; no ejecuta `Animator` ni refleja automáticamente un rig con `AnimationConstraint` y sus attachments reales. Úsalo para revisar la silueta y el orden temporal, no para certificar el signo o el contacto en Studio. No cambies el adaptador ni los signos de clips existentes sin una comparación de referencia en el rig objetivo. Para mostrar el frente, gira la cámara alrededor del rig; no rotes la raíz para compensar la cámara.

Los quince nombres corporales admitidos por defecto son:

```text
LowerTorso, UpperTorso, Head,
RightUpperArm, RightLowerArm, RightHand,
LeftUpperArm, LeftLowerArm, LeftHand,
RightUpperLeg, RightLowerLeg, RightFoot,
LeftUpperLeg, LeftLowerLeg, LeftFoot
```

No inventes aliases. Si el rig usa una jerarquía o nombres distintos, inspecciónalo antes de generar JSON.

## Ejes y posiciones

- Trata `x`, `y` y `z` como ejes locales del joint.
- No asumas signos por intuición espacial ni por espejo matemático.
- Calibra un eje primero con cambios pequeños, por ejemplo `±5°` o `±10°`. Si la diferencia no se distingue en el visor, usa una muestra de calibración más visible; no reutilices esa magnitud grande como pose final.
- Genera una prueba aislada desde «Crear prueba de calibración» o con `python scripts/create_joint_calibration.py --joint LeftUpperArm --axis z`. Compara positivos (frames 12–24) y negativos (44–56), y confirma que los intervalos entre ellos vuelvan a neutral. Para el rig blocky aproximado del visor, las muestras de referencia actuales usan `±25°` en brazo y `±1` stud en `LowerTorso.position.y` para que la diferencia se lea claramente.
- Durante la calibración de `LowerTorso.position`, el visor fija la cámara al centro de la pose inicial para que el seguimiento automático no oculte el desplazamiento. La muestra de `±1` stud sirve para identificar el signo, no como amplitud recomendada de una animación.
- El archivo incluye un objeto opcional `calibration` con las etiquetas de fase que lee el visor. AI Fight Animator solo consume `keyframes` y omite este metadato; no lo uses como campo de movimiento para clips normales.
- Registra el resultado por pieza, eje, signo visible y rig probado. No conviertas el resultado de `LeftUpperArm.z` en regla para `RightUpperArm.z` ni para otro avatar.
- `calibrar_LowerTorso_position_y_r15.json` aplica esta prueba a la traslación vertical del root visual. No la confundas con movimiento del `HumanoidRootPart` ni con desplazamiento físico.
- Calibración observada en este visor R15 blocky: `LeftUpperArm.z = +25°` abre el brazo hacia fuera; `−25°` lo acerca al torso; `+90°` lo deja aproximadamente horizontal hacia el lado izquierdo. En el mismo adaptador, `LowerTorso.position.y = +1` baja el cuerpo y `−1` lo eleva. Son referencias locales del visor, no reglas universales ni calibración de Roblox Studio.
- Prueba de signo en el mismo rig del visor, con cámara de perfil anclada a la pose neutral: `LowerTorso.position.z = +1` desplaza visualmente el cuerpo hacia delante (hacia la cara local del rig); `−1` hacia atrás. No deduzcas de aquí movimiento físico del `HumanoidRootPart`, ni traslades el signo a Studio sin comprobarlo.
- Prueba el espejo funcional de cada lado; una pose simétrica visualmente no siempre usa valores idénticos con signo opuesto.
- Prefiere rotación para extremidades. Una traslación grande de brazos, piernas, manos o pies puede abrir huecos, desenganchar la silueta y retargetear mal.
- Usa `position` principalmente para el root visual (`LowerTorso`) o para microcorrecciones ya verificadas.
- No derives límites anatómicos universales de un solo avatar. El skinning y las proporciones cambian la apariencia del mismo ángulo.

## Flujo de construcción

### 1. Define la línea de acción

Resume la pose en una frase física: “peso sobre pierna izquierda y pecho proyectado al golpe”, “cadera alta durante el paso” o “dos manos cierran sobre el eje del arma”.

Marca:

- base de soporte;
- centro de masa aparente;
- dirección del pecho y pelvis;
- extremidad conductora;
- contacto o silueta que debe leerse.

### 2. Construye las poses narrativas

Para una acción única usa, según corresponda:

1. pose inicial;
2. anticipación;
3. aceleración o despegue;
4. contacto, impacto o máxima extensión;
5. follow-through;
6. recuperación o nueva pose final.

No añadas todas las fases por obligación. Un gesto pequeño puede necesitar tres poses; una acrobacia puede necesitar varias poses de transición para conservar el arco y evitar giros ambiguos.

Para locomoción cíclica usa como base:

1. contacto;
2. descenso;
3. passing;
4. ascenso;
5. contacto opuesto;
6. segunda mitad espejada funcionalmente;
7. cierre idéntico al inicio.

### 3. Resuelve de grande a pequeño

Orden recomendado:

1. `LowerTorso` y soporte de piernas;
2. `UpperTorso` y dirección del pecho;
3. upper limbs conductores;
4. lower limbs y contactos;
5. cabeza;
6. manos y pies;
7. overlap, recoil y microajustes.

No intentes arreglar una trayectoria corporal rota con la muñeca o el pie.

### 4. Diseña el timing

Convierte tiempo a frames con:

```text
frame = round(segundos × FPS)
```

Usa porcentajes antes de fijar números absolutos. Como punto de partida para una acción enérgica:

- 0–20%: preparación;
- 20–45%: aceleración;
- 45–55%: impacto o lectura máxima;
- 55–75%: follow-through;
- 75–100%: recuperación.

Adáptalo a masa, intención y estilo. Un golpe fuerte suele tener anticipación legible, salida rápida, hold muy corto y recuperación más lenta. Un movimiento pesado necesita más tiempo para arrancar y asentarse.

### 5. Añade breakdowns con propósito

Añade una pose intermedia solo si corrige uno de estos problemas:

- arco incorrecto;
- pie o mano atravesando geometría;
- giro que el interpolador resuelve por el camino corto;
- cambio brusco de silueta;
- centro de masa incoherente;
- contacto que resbala;
- overlap o drag ausente.

No hornees un keyframe en cada frame salvo que el movimiento capturado lo requiera.

### 6. Ajusta easing en Moon Animator

El easing es parte del movimiento, pero el esquema JSON personalizado de este repositorio no contiene easing. Después de importar:

- usa lineal solo cuando la velocidad constante sea intencional;
- usa cubic/ease-in para acumulación o entrada lenta;
- usa cubic/ease-out para frenado y asentamiento;
- usa ease-in-out para transiciones suaves sin impacto;
- usa constant para cambios deliberadamente instantáneos;
- revisa la curva y el spacing a velocidad normal, no solo frame por frame.

## Recetas por familia

### Idle

- Mantén el centro de masa dentro de la base de soporte.
- Desfase sutil entre pelvis, pecho, cabeza y brazos.
- Evita que todos los joints cambien de dirección en el mismo frame.
- Roblox no interpola del último keyframe al primero al repetir un clip; copia la pose inicial al frame final. Iguala esos extremos y revisa también la velocidad en la costura para que no haya frenazo perceptible.
- Activa el loop en Moon Animator o en `AnimationTrack.Looped`; el JSON de este importador no puede activarlo. Configura la prioridad por separado en Moon Animator o `AnimationTrack.Priority`.
- Para comprobar la igualdad de los extremos, ejecuta `python scripts/validate_animation_json.py clip.json --loop`; esto revisa datos y no sustituye la inspección visual de velocidad.
- `respiracion_idle_r15.json` es una primera pasada en 0/15/30/45/60 frames: usa amplitud pequeña en `LowerTorso`, `UpperTorso` y `Head`, con pose igual en 0 y 60. Revisa si el movimiento se alcanza a leer sin que el cuerpo parezca saltar; no lo tomes como calibración aprobada hasta que el usuario lo vea.

### Caminata o carrera

- Bloquea visualmente el pie de apoyo; no debe deslizarse.
- Coordina pelvis vertical/lateral, contragiro de torso y braceo opuesto.
- La carrera añade fase aérea; la caminata conserva al menos un contacto.
- Valida el ciclo desde perfil para longitud de paso y desde frente para balance lateral.
- Caminata in-place validada por el usuario en el rig probado: 60 frames a 60 FPS, poses en 0/15/30/45/60 y frame 60 igual al 0. En el primer apoyo, `RightUpperLeg.x = -22°` y `LeftUpperLeg.x = 22°`; en el apoyo opuesto se invierten, con braceo contrario. Estos valores son referencia local, no un preset universal.

### Saludo con la mano derecha

- En el rig probado en viewport, `RightUpperArm.z = -130°` levantó el brazo hacia afuera; `+130°` lo metió hacia el torso. Esta dirección solo está confirmada para ese rig.
- La primera pasada aprobada mantuvo `RightLowerArm.z = -55°`, alternó `RightHand.z` entre `+20°` y `-20°` durante el vaivén y volvió a neutral al final.
- Conserva el contraste entre levantar el brazo, sostenerlo durante el saludo y bajarlo. Revisa frente y perspectiva para detectar penetración del hombro o del brazo.
- Trata estos valores como una calibración observada del rig mostrado, no como una regla para el brazo izquierdo ni para otros avatares.

### Golpe recto

Cadena visual: apoyo y pelvis → torso → `UpperArm` → `LowerArm` → `Hand`.

- La mano contraria conserva guardia o funciona como contrapeso.
- El codo no debe hiperextenderse en impacto.
- El puño no corrige por sí solo una mala línea del hombro.
- En el rig local que originó este documento, mantener `LowerArm.x` cerca de `0` durante el impacto evitó que el antebrazo cayera; `LowerArm.z` sirvió como microalineación. Trátalo como calibración local y valida ambos lados.

### Guardia básica

- Mantén los antebrazos flexionados, puños cerca del torso y el peso repartido antes de construir un golpe.
- `guardia_base_r15.json` toma los quince offsets del frame inicial del golpe recto derecho del mismo conjunto y los mantiene hasta el frame 24. Esto sirve como muestra reutilizable, pero esa adaptación está pendiente de confirmación visual del usuario.
- No trates esta pose como una guardia universal: ajusta distancia entre puños, apertura de codos y orientación frontal en el rig objetivo.
- Para usar una muestra del directorio junto al visor, abre `r15_animation_viewer.html?sample=nombre_del_archivo_sin_extension`; por ejemplo `?sample=guardia_base_r15`. La ruta solo admite nombres simples de archivo y carga el JSON de esa carpeta.

### Avance corto y caída a rodilla

- La traslación de `LowerTorso` es una pose del motor `Root`, relativa a `HumanoidRootPart`; no mueve por sí sola el `HumanoidRootPart` ni garantiza root motion físico en gameplay.
- No cambies el signo de `LowerTorso.position.z` basándote únicamente en la etiqueta “frente local -Z”. El JSON, el adaptador del visor y los ejes/pivotes del avatar deben calibrarse juntos. La V2 se conserva como la muestra de referencia anterior; la V3 fue un experimento de signo y no se debe tratar como validada en Studio.
- Conserva la posición avanzada en la pose final si la acción termina agachada/arrodillada; no interpoles un regreso a cero si el usuario pidió quedarse allí.
- Valida primero en perfil para revisar el avance y la rodilla en el suelo, luego en frente para comprobar la silueta. La cámara del visor no debe girar la raíz del rig para corregir el ángulo.

### Agacharse y levantarse

- Reparte la flexión entre cadera y rodilla de ambos lados; no intentes bajar el cuerpo solo rotando `LowerTorso`.
- Inclina ligeramente el torso hacia delante y lleva los brazos al frente como contrapeso, sin despegar visualmente los pies.
- Añade una pausa breve en la posición baja para que se lea la sentadilla; vuelve a la pose neutra de forma progresiva.
- Usa `LowerTorso.position.y` solo como ajuste visual pequeño del cuerpo en el visor. Ese offset relativo al motor `Root` no mueve el `HumanoidRootPart` ni implementa la postura física de agachado en gameplay.
- El clip `agacharse_y_levantarse_r15.json` es una primera pasada para el rig aproximado; confirma la profundidad de la sentadilla y el contacto de los pies antes de convertir sus ángulos en una regla calibrada.

### Patada, salto o aterrizaje

- Define primero pierna de apoyo, trayectoria de la cadera y contacto final.
- En el aire, tuck y apertura deben anticipar el aterrizaje.
- En aterrizaje distribuye la absorción entre pies, rodillas, cadera y torso.
- No resuelvas un mortal con un único salto de `0°` a `360°`: ambas orientaciones son equivalentes y la interpolación puede escoger un giro no deseado. Inserta cuartos o medias vueltas visualmente verificadas.

### Cadena de saltos de parkour

- Separa cada salto en carga, despegue, arco aéreo, preparación de aterrizaje, compresión y rebote. Evita comenzar el segundo salto antes de que el primer aterrizaje tenga una pose legible.
- Alterna las piernas durante el segundo salto para que la secuencia no parezca dos saltos verticales idénticos; usa ambos pies para absorber la recepción final.
- Para una trayectoria con avance visual en el adaptador local ya calibrado, aumenta gradualmente `LowerTorso.position.z` entre impulsos y conserva el avance al final; evita saltos bruscos de posición entre keyframes.
- Comprueba el arco en perfil y la silueta desde frente/tres cuartos. El visor centra la cámara en el root animado, por lo que sigue el personaje; observa también cómo se desplaza el suelo y no confundas el seguimiento de cámara con ausencia de avance.
- Este avance de `LowerTorso` es solo relativo a `HumanoidRootPart`; gameplay necesita locomoción o root motion del controlador.

### Agarre a dos manos

- El objeto o eje imaginario es la restricción principal.
- Coloca primero la mano líder y después resuelve la mano secundaria hacia el mismo punto.
- Usa upper arms para trayectoria, lower arms para cierre y hands para orientación final.
- Recurre a microtraslación del upper arm solo después de agotar rotaciones razonables y revisar hombros/codos.
- Para un objeto real, usa el flujo de weld/prop de Moon Animator en vez de fingir el contacto solo con el cuerpo.

## Contrato JSON del importador de este repositorio

Estas reglas proceden de `lua-src/Animator/Windows/AIFightAnimator.lua`; describen esta integración, no una función oficial estándar de Moon Animator 2.

### Semántica real

- `joint` identifica el nombre de la pieza animada que usa el track, por ejemplo `RightUpperArm`; no es el nombre de la instancia `Motor6D`. En jerarquías anidadas puede ser una ruta con puntos, y el importador también busca por su último segmento.
- La aplicación usa el nombre escrito en el campo objetivo o, si está vacío, el objeto activo. La comparación ignora mayúsculas y espacios exteriores, pero el resto del nombre debe coincidir. `target_name` puede rellenar ese campo en el flujo de exportación local; al pegar JSON manualmente no reemplaza necesariamente la selección de la UI.
- Cada `frame` es un **offset** sumado al cursor actual de Moon Animator.
- El frame de destino se redondea al entero más cercano.
- La rotación usa grados XYZ.
- La posición usa studs XYZ.
- La composición aplicada es:

```text
baseCFrame * CFrame.new(px, py, pz) * CFrame.Angles(rx, ry, rz)
```

- `fps`, `total_frames`, `description` e `intensity` son metadatos para este importador; no cambian por sí solos el FPS ni el largo de la timeline.
- El FPS activo de Moon Animator controla el tiempo real. Configúralo antes de importar.
- El importador no aplica easing desde JSON. Ajústalo después en la timeline.
- Un joint desconocido se omite.
- Si se repite el mismo joint en el mismo frame, el último valor termina ganando. Prohíbe duplicados en la salida.
- Si el cursor actual más el último offset excede la longitud de la timeline, Moon Animator puede sujetar la inserción al final. Amplía primero la timeline.
- El decodificador acepta el objeto raíz o un wrapper `{ "animation": { ... } }`, pero emite el objeto raíz directo salvo que un consumidor exija el wrapper.

### Esquema de salida

```json
{
  "animation_name": "golpe_recto_derecho",
  "description": "Golpe in-place con recuperación a guardia",
  "total_frames": 30,
  "fps": 60,
  "intensity": 0.8,
  "target_name": "Rig",
  "keyframes": [
    {
      "joint": "LowerTorso",
      "frame": 0,
      "rotation": { "x": 0, "y": 0, "z": 0 },
      "position": { "x": 0, "y": 0, "z": 0 }
    },
    {
      "joint": "LowerTorso",
      "frame": 30,
      "rotation": { "x": 0, "y": 0, "z": 0 },
      "position": { "x": 0, "y": 0, "z": 0 }
    }
  ]
}
```

El ejemplo demuestra el formato, no constituye una animación corporal completa.

### Reglas de emisión

Al generar JSON:

- entrega JSON sintácticamente válido, sin comentarios ni `null`;
- usa números finitos, no strings numéricos;
- incluye siempre `rotation.x/y/z` y `position.x/y/z` en cada entrada;
- usa frames enteros mayores o iguales a cero;
- asegura `max(frame) <= total_frames`;
- evita más de una entrada por par `(joint, frame)`;
- ordena por frame ascendente y, dentro del frame, por el orden canónico de joints;
- redondea normalmente a tres decimales;
- en un clip autónomo, define en frame 0 todos los joints cuyo estado deba quedar controlado;
- usa frames intermedios parciales solo para joints que realmente cambian;
- al volver a neutral o cerrar un loop, explicita en el frame final todos los joints animados;
- no declares que el clip tiene easing, prioridad, loop o root motion si el JSON no puede representarlo;
- no uses `position` de extremidades como solución rutinaria.

Incluir los quince joints en frame 0 es una opción robusta para un clip totalmente autónomo, no una exigencia estructural del importador. Evita llenar todos los frames con ceros innecesarios.

## Movimiento in-place frente a desplazamiento

Aclara esta diferencia:

- Una transformación de `LowerTorso` puede producir desplazamiento visual relativo al `HumanoidRootPart` dentro del clip.
- Eso no garantiza desplazamiento físico autoritativo del personaje durante gameplay.
- Para gameplay, coordina la animación in-place con movimiento del controlador, velocidad del `Humanoid`, root motion soportado o lógica de servidor/cliente del proyecto.
- Para cutscenes, puede ser apropiado animar el rig o su root como objeto de escena.

No prometas root motion funcional solo porque el personaje se desplaza en el preview.

## Validación visual obligatoria

Revisa al menos:

- silueta clara desde la cámara principal;
- centro de masa coherente con el apoyo o fase aérea;
- pies sin deslizamiento durante contacto;
- rodillas alineadas de forma plausible con pies y cadera;
- codos sin hiperextensión ni colapso;
- manos y pies orientados al contacto;
- torso y pelvis con compensación suficiente;
- cabeza con intención, sin vibración ni sobrecompensación;
- ausencia de huecos producidos por traslaciones de joints;
- ausencia de penetraciones no intencionales;
- arcos continuos y sin flips de Euler;
- primer/último frame y velocidad de costura correctos en loops;
- lectura a velocidad normal, cámara frontal, perfil y perspectiva;
- reproducción en el avatar final, no solo en el rig de autoría.

Si no puedes ver el resultado en Moon Animator, etiqueta los números como primera pasada y solicita una captura frontal/perfil o el JSON exportado de una pose corregida. La validación visual tiene prioridad sobre conservar un valor propuesto.

### Comparar vistas sin confundir la cámara con el rig

- Congela el frame de la pose y alterna las cámaras del visor; no animes ni rotes el personaje para conseguir otra vista.
- Usa frente para simetría y lectura de silueta, perfil para extensión, flexión de rodilla/codo y apoyo, y perspectiva para la lectura general.
- Un puño o pie que apunta hacia la cámara se ve más corto de frente. Antes de cambiar la rotación, comprueba el mismo frame de perfil y tres cuartos. Si la cadena proximal-distal está extendida de perfil y el objetivo es golpear hacia cámara, conserva la pose y registra la limitación de perspectiva.
- En acciones con giro de torso, una cámara lateral fija puede mirar al costado o a la espalda del personaje después del giro. Registra qué plano está mostrando y evalúa la línea de acción en una vista adicional; no deduzcas dirección mundial solo por el nombre «frente/perfil».
- Mantén la distinción de certeza: “revisada visualmente en el visor” no significa “aprobada por el usuario” ni “validada en Studio”.

Para revisar una muestra en el navegador local servido por HTTP, abre `http://127.0.0.1:5500/r15_animation_viewer.html?sample=nombre_del_json_sin_extension`. Ajusta el slider al frame de preparación, acción e impacto, inspecciona frente y perfil manteniendo el frame, y toma perspectiva para confirmar la lectura general. Si se trata de un golpe dirigido hacia cámara, incluye un ángulo tres cuartos para compensar el acortamiento frontal.

## Diagnóstico rápido

Cuando algo se ve mal, corrige en este orden:

1. timing y pose clave;
2. soporte y centro de masa;
3. pelvis y torso;
4. segmento proximal de la extremidad;
5. segmento distal;
6. mano o pie;
7. easing y microajustes.

Síntomas frecuentes:

- **brazo flotante:** falta torso, clavícula visual o soporte; revisa `UpperTorso` y `UpperArm` antes de `Hand`;
- **antebrazo cae en un golpe:** reduce la flexión local, recalibra el eje y alinea desde upper/lower arm;
- **pie resbala:** fija el contacto y reajusta pelvis/longitud de paso;
- **movimiento robótico:** mejora spacing, offsets temporales y easing; no añadas ruido aleatorio;
- **loop salta:** iguala pose y tangente visual de la costura;
- **giro toma el camino corto:** añade breakdowns intermedios;
- **manos no coinciden con el objeto:** resuelve el objeto y ambas cadenas de brazo en conjunto;
- **JSON entra demasiado tarde:** el cursor no estaba en el frame esperado;
- **JSON se amontona al final:** la timeline era más corta que cursor + último offset;
- **duración incorrecta:** el FPS del JSON no modificó el FPS activo de Moon Animator.

## Protocolo de respuesta

Si el usuario pide una animación nueva:

1. declara los supuestos relevantes en una línea;
2. da una tabla corta de poses/frames cuando ayude a revisar la intención;
3. entrega el JSON completo si fue solicitado;
4. separa los pasos manuales posteriores: largo de timeline, FPS, easing, loop, prioridad y exportación;
5. pide evidencia visual solo para la siguiente iteración, sin bloquear una primera pasada razonable.

Si el usuario pide solo JSON, devuelve únicamente el objeto JSON válido.

Si el usuario comparte un JSON:

1. valida estructura y pares duplicados;
2. confirma unidades, FPS activo y cursor de inserción;
3. revisa coherencia de poses por frame;
4. propone cambios concretos por joint y frame;
5. no reescribas valores que ya funcionan sin una razón observable.

Si el usuario comparte video o capturas, usa esa evidencia como fuente principal para timing, contacto, balance y silueta. No adivines signos locales cuando puedan verificarse.

## Límites

- No inventes documentación específica de v36000.
- No uses tablas numéricas antiguas como presets universales.
- No afirmes rangos anatómicos absolutos para todos los R15.
- No confundas body parts con ejes globales.
- No garantices compatibilidad con R6 o custom rigs.
- No incluyas animación facial: este esquema cubre los quince joints corporales.
- No publiques ni sobrescribas animaciones del usuario sin autorización explícita.

## Registro de aprendizaje confirmado

Mantén aquí la diferencia entre lo que el usuario aprobó visualmente y los borradores. El silencio o el cambio de tema no cuentan como aprobación. Las confirmaciones del visor local solo calibran ese rig y ese adaptador; no prueban el comportamiento en Roblox Studio.

| Muestra | Estado | Evidencia y alcance |
|---|---|---|
| `giro_y_marcha_r15.json` | Aprobada en el visor local | El usuario confirmó el resultado. Sirve como referencia de giro visual y marcha en ciclo; no mueve físicamente `HumanoidRootPart`. |
| `salto_y_aterrizaje_r15.json` | Aprobada en el visor local | El usuario confirmó el resultado. Sirve como secuencia visual de compresión, elevación, impacto y recuperación; no implementa la física de salto. |
| `marcha_r15.json` | Aprobada en el visor local | El usuario confirmó que la marcha quedó perfecta. |
| `agacharse_y_levantarse_r15.json` | Revisada visualmente en el visor; pendiente del usuario | Frame 18: rodillas flexionadas en ambos lados y pies apoyados de perfil; de frente la profundidad se lee poco. Revisar el perfil para valorar la sentadilla. |
| `guardia_base_r15.json` | Pendiente de revisión | Pose derivada del frame inicial del golpe derecho; comprobar ubicación de puños, codos y lectura frontal. |
| `respiracion_idle_r15.json` | Pendiente de revisión | Ciclo sutil de 60 frames; comprobar amplitud, lectura a velocidad normal y continuidad de la costura. |
| `calibrar_LeftUpperArm_z_r15.json` | Revisada visualmente en el visor; pendiente del usuario | `±25°` separa claramente apertura hacia fuera y aducción al torso; `+90°` da una referencia de brazo lateral horizontal. |
| `calibrar_LowerTorso_position_y_r15.json` | Revisada visualmente en el visor; pendiente del usuario | `±1` stud se ve con cámara anclada: positivo baja el cuerpo y negativo lo eleva. Es una prueba de signo, no una amplitud de clip. |
| `brazo_izquierdo_recto_lateral_r15_v1.json` | Revisada visualmente en el visor; pendiente del usuario | En frame 14, el brazo izquierdo se lee extendido horizontal desde frente y hacia fuera desde perfil. Conserva la pose actual; aún no prueba el avatar real de Studio. |
| `alzar_brazo_izquierdo_r15_v1.json` | Revisada visualmente en el visor; pendiente del usuario | En frame 18, el brazo izquierdo se lee alzado con el codo flexionado desde frente y perfil; `LeftUpperArm.z` positivo abre el brazo hacia fuera en esta aproximación. |
| `punete_recto_derecho_r15_v1.json` | Revisada visualmente en el visor; pendiente del usuario | Frame 20: el puño se proyecta hacia delante en vista frontal/tres cuartos. La vista frontal lo acorta; el perfil se interpreta junto con el giro del torso, no de forma aislada. |
| `punete_recto_izquierdo_r15_v1.json` | Revisada visualmente en el visor; pendiente del usuario | Frame 20: extensión legible desde frente/tres cuartos y perfil, con el torso acompañando el golpe. |
| `patada_lateral_alta_giro_r15.json` | Revisada visualmente en el visor; pendiente del usuario | Frame 20: pierna elevada y extendida lateralmente desde frente/tres cuartos; el giro de torso y el ángulo de perfil ocultan parte de la pierna. Confirmar con el usuario antes de tratarla como patrón aprobado. |
| `cadena_salto_parkour_r15.json` | Revisada visualmente en el visor; pendiente del usuario | Dos saltos con avance visual, aterrizaje amortiguado y rebote. Revisados frames 8, 18, 26, 38, 46, 50 y 64 en perfil/frente; comprobar el timing y la recepción con el usuario. El avance local usa la calibración visual de `LowerTorso.position.z`, no root motion físico. |

Las demás muestras del directorio son ejercicios, referencias o borradores hasta que el usuario confirme explícitamente su resultado.

Las copias de clips cargados o revisados durante el desarrollo están en `json_probados/`; su `README.md` diferencia aprobación explícita, revisión visual local y calibraciones. Esa carpeta sirve como banco de ejemplos, no como garantía de compatibilidad universal.

## Cliente IA y backend del plugin

El cliente de `lua-src/Animator/Windows/AIFightAnimator.lua` envía esta petición al servidor local:

```json
{
  "prompt": "puñete recto con la mano derecha",
  "duration": 30,
  "intensity": 0.7,
  "target_name": "Rig"
}
```

La ventana solo trata la generación como exitosa cuando la respuesta contiene `success: true` y `animation` como objeto. El objeto `animation` debe incluir `keyframes` para que el importador pueda insertarlo. Al cargar JSON manualmente, en cambio, el decodificador acepta tanto el objeto de animación en la raíz como `{ "animation": { ... } }`.

El cliente Lua no envía el contenido de esta skill. Para que la generación IA del plugin aplique estas reglas, el backend de `/generate` debe incluir instrucciones equivalentes en su prompt de sistema o configuración de generación y devolver la animación dentro de `animation`. La fuente del backend no está presente en este repositorio, así que no se puede afirmar que hoy use esta skill ni modificar su prompt desde aquí.

Hay un prompt de sistema propuesto en [server-generation-prompt.md](server-generation-prompt.md), listo para integrarlo cuando aparezca el backend. La unidad de `duration` no se determina desde el cliente; ese prompt anota una convención provisional en vez de presentarla como un hecho.

## Fuentes verificadas

Comprobado el 15 de octubre de 2026:

- [Moon Animator 2 en Creator Store](https://create.roblox.com/store/asset/4725618216/Moon-Animator-2%2Bidk): ficha oficial de `@xsixx`, actualizada en agosto de 2026 y marcada `V36000`.
- [Tutorial oficial básico de Moon Animator 2](https://www.youtube.com/watch?v=q8tGNMo_jHg): instalación, keyframes, easing, largo de timeline, Easy Weld, cámaras, exportación/importación y markers.
- [Pose — Roblox Creator Hub](https://create.roblox.com/docs/reference/engine/classes/Pose): jerarquía R15, nombres de piezas y aplicación de `Pose.CFrame` mediante `Transform`.
- [Motor6D — Roblox Creator Hub](https://create.roblox.com/docs/es-es/reference/engine/classes/Motor6D): `Transform` es un `CFrame` animado del motor. La página española indica que el texto se traduce con IA; usa también la referencia inglesa para matices de API.
- [Motor6D.Transform — Roblox Creator Hub](https://create.roblox.com/docs/reference/engine/classes/Motor6D/Transform): uso, escritura por Animator, comportamiento por frame y estado actual de Avatar Joint Upgrade.
- [AnimationTrack — Roblox Creator Hub](https://create.roblox.com/docs/reference/engine/classes/AnimationTrack): loop y prioridad de la pista de reproducción en runtime.
- [JointInstance — Roblox Creator Hub](https://create.roblox.com/docs/reference/engine/classes/JointInstance): semántica de `C0`, `C1`, `Part0` y `Part1`.
- [CFrame — Roblox Creator Hub](https://create.roblox.com/docs/reference/engine/datatypes/CFrame): `CFrame.Angles` equivale a la rotación XYZ.
- [Characters — Roblox Creator Hub](https://create.roblox.com/docs/characters): estándar corporal y joints poseables de R15.
- [Animation Editor — Roblox Creator Hub](https://create.roblox.com/docs/animation/editor): estilos y direcciones de easing, looping, duplicación de la pose inicial al cierre y prioridad.
- [AnimationConstraint — Roblox Creator Hub](https://create.roblox.com/docs/reference/engine/classes/AnimationConstraint): reemplazo predeterminado de `Motor6D` en rigs avatar R15 nuevos con Avatar Joint Upgrade, mapeo de attachments y equivalencia de `Transform`.
- Código local: `lua-src/Animator/Windows/AIFightAnimator.lua` para el contrato real del JSON y `lua-src/Animator/Main.server.lua` para el FPS predeterminado de esta copia.

Si una afirmación futura depende de la versión, vuelve a verificar primero la ficha oficial y la interfaz instalada.
